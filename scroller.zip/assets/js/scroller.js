/*
 Scroller v1.0.0
------------
 Scroller is a Jquery plugin depends on animate.css and it's the easiest way to add animation on page scroll using the Animate.css classes.
------------
 Mossad Osami
 moelnew@gmail.com
------------
 2016-07-14
------------
 Scroller! 
 Copyright 2016
 Licensed under the Apache License v2.0
 http://www.apache.org/licenses/LICENSE-2.0
 */
jQuery(document).ready(function(a){"use strict";var i=a("body"),t=a("[moel-ani-data]"),n=a(window),o=function(){var a=document;return Math.max(Math.max(a.body.scrollHeight,a.documentElement.scrollHeight),Math.max(a.body.offsetHeight,a.documentElement.offsetHeight),Math.max(a.body.clientHeight,a.documentElement.clientHeight))};if(t.length){i.append("<style>.after-0-5s{-webkit-animation-delay:0.5s;animation-delay:0.5s}.for-0-5s{-webkit-animation-duration:0.5s;animation-duration:0.5s}.after-1s{-webkit-animation-delay:1s;animation-delay:1s}.for-1s{-webkit-animation-duration:1s;animation-duration:1s}.after-1-5s{-webkit-animation-delay:1.5s;animation-delay:1.5s}.for-1-5s{-webkit-animation-duration:1.5s;animation-duration:1.5s}.for-2s{-webkit-animation-duration:2s;animation-duration:2s}.after-2s{-webkit-animation-delay:2s;animation-delay:2s}.for-2-5s{-webkit-animation-duration:2.5s;animation-duration:2.5s}.after-2-5s{-webkit-animation-delay:2.5s;animation-delay:2.5s}.for-3s{-webkit-animation-duration:3s;animation-duration:3s}.after-3s{-webkit-animation-delay:3s;animation-delay:3s}.for-3-5s{-webkit-animation-duration:3.5s;animation-duration:3.5s}.after-3-5s{-webkit-animation-delay:3.5s;animation-delay:3.5s}.for-4s{-webkit-animation-duration:4s;animation-duration:4s}.after-4s{-webkit-animation-delay:4s;animation-delay:4s}.for-4-5s{-webkit-animation-duration:4.5s;animation-duration:4.5s}.after-4-5s{-webkit-animation-delay:4s;animation-delay:4s}.for-5s{-webkit-animation-duration:5s;animation-duration:5s}.after-5s{-webkit-animation-delay:5s;animation-delay:5s}.for-5-5s{-webkit-animation-duration:5.5s;animation-duration:5.5s}.after-5-5s{-webkit-animation-delay:5.5s;animation-delay:5.5s}</style>"),t.css("visibility","hidden"),i.css("overflow-x","hidden");var s=a(window).scrollTop()+a(window).height();a.each(t,function(i,t){var n=a(t),o=n.attr("moel-ani-data"),e=n.offset().top,d=n.height();s>e&&e+n.height()<s+d&&n.addClass(o).css("visibility","visible").addClass("animated")}),n.on("scroll resize",function(){var i=a(window).scrollTop()+a(window).height();a.each(t,function(t,s){var e=a(s),d=e.attr("moel-ani-data"),r=e.offset().top,m=e.height();i>r&&r+e.height()<i+m?e.addClass(d).css("visibility","visible").addClass("animated"):n.scrollTop()+n.height()===o()&&e.addClass(d).css("visibility","visible").addClass("animated")})})}});